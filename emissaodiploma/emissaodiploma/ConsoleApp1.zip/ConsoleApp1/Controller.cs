﻿/// CONTROLLER
/// Coordena a interação entre View e Model
public class Controller
{
    private readonly Model _model;

    public Controller(Model model)
    {
        _model = model;
    }

    /// Inicia o processo de emissão
    public void EmitirDiploma(string nomeAluno, string curso)
    {
        _model.EmitirDiploma(nomeAluno, curso);
    }
}