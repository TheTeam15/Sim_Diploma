﻿using PdfSharp.Pdf;
using PdfSharp.Drawing;
using System.IO;

/// Implementação concreta do gerador de diplomas.
/// 
/// Esta classe utiliza a biblioteca PDFsharp para criar o documento.
/// 
/// NOTA:
/// - Esta classe é usada através da interface IGeradorDiploma
/// - O Model não conhece PDFsharp diretamente
public class Gerador : IGeradorDiploma
{
    public byte[] Gerar(string nomeAluno, string curso)
    {
        // =========================
        // CRIAÇÃO DO DOCUMENTO
        // =========================

        PdfDocument documento = new PdfDocument();
        PdfPage pagina = documento.AddPage();

        // Permite desenhar conteúdo na página
        XGraphics gfx = XGraphics.FromPdfPage(pagina);

        // =========================
        // CONFIGURAÇÃO VISUAL
        // =========================

        XFont titulo = new XFont("Arial", 20);
        XFont normal = new XFont("Arial", 12);

        double largura = pagina.Width.Point;

        // =========================
        // CONTEÚDO DO DIPLOMA
        // =========================

        gfx.DrawString("Diploma", titulo, XBrushes.Black,
            new XRect(0, 50, largura, 50),
            XStringFormats.TopCenter);

        gfx.DrawString(nomeAluno, titulo, XBrushes.Black,
            new XRect(0, 120, largura, 50),
            XStringFormats.TopCenter);

        gfx.DrawString($"Curso: {curso}", normal, XBrushes.Black,
            new XRect(0, 180, largura, 50),
            XStringFormats.TopCenter);

        // =========================
        // EXPORTAÇÃO
        // =========================

        using (MemoryStream stream = new MemoryStream())
        {
            documento.Save(stream);
            return stream.ToArray();
        }
    }
}