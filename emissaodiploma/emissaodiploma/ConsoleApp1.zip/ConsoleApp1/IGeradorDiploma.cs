﻿/// Interface que define o contrato de geração de diplomas.
/// 
/// Esta interface permite desacoplar o Model da tecnologia usada.
/// O Model depende desta abstração e não da implementação concreta.
/// 
/// Vantagem:
/// - Permite trocar PDFsharp por outra solução sem alterar o Model
public interface IGeradorDiploma
{
    /// Gera um diploma em formato PDF (array de bytes)
    byte[] Gerar(string nomeAluno, string curso);
}
