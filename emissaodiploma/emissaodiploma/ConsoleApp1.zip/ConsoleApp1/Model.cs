﻿using System;

/// Classe para transportar resultado da validação
public class ValidacaoEventArgs
{
    public bool Sucesso { get; }
    public string Mensagem { get; }

    public ValidacaoEventArgs(bool sucesso, string mensagem)
    {
        Sucesso = sucesso;
        Mensagem = mensagem;
    }
}

/// Classe para transportar o diploma gerado
public class DiplomaEmitidoEventArgs
{
    public byte[] PdfBytes { get; }

    public DiplomaEmitidoEventArgs(byte[] pdfBytes)
    {
        PdfBytes = pdfBytes;
    }
}

/// Classe de apoio (simplificada)
public class Inscricao
{
    public string NomeAluno { get; set; } = "";
    public string Curso { get; set; } = "";
    public int? ClassificacaoFinal { get; set; }
    public string Estado { get; set; } = "";
}

/// MODEL
/// Responsável por:
/// - Regras de negócio
/// - Validação
/// - Coordenação da emissão
/// - Comunicação com a View
public class Model
{
    // Dependência via interface (baixo acoplamento)
    private readonly IGeradorDiploma _gerador;

    // Eventos (comunicação com a View)
    public event EventHandler<ValidacaoEventArgs>? OnValidacao;
    public event EventHandler<DiplomaEmitidoEventArgs>? OnDiplomaEmitido;

    public Model(IGeradorDiploma gerador)
    {
        _gerador = gerador;
    }

    /// Verifica se o aluno pode obter diploma (RG07)
    private void ValidarElegibilidade(Inscricao inscricao)
    {
        if (inscricao.ClassificacaoFinal == null)
            throw new Exception("Sem classificação.");

        if (inscricao.ClassificacaoFinal < 10)
            throw new Exception("Sem aproveitamento.");

        if (inscricao.Estado != "Concluida")
            throw new Exception("Inscrição não concluída.");
    }

    /// Método principal da emissão
    public void EmitirDiploma(string nomeAluno, string curso)
    {
        try
        {
            // Simulação de dados (no sistema real vem da BD)
            Inscricao inscricao = new Inscricao
            {
                NomeAluno = nomeAluno,
                Curso = curso,
                ClassificacaoFinal = 14,
                Estado = "Concluida"
            };

            // Validação
            if (string.IsNullOrWhiteSpace(nomeAluno))
                throw new Exception("Nome inválido.");

            // Regras de negócio
            ValidarElegibilidade(inscricao);

            // Notifica sucesso
            OnValidacao?.Invoke(this,
                new ValidacaoEventArgs(true, "Validação com sucesso."));

            // Geração do PDF (via interface)
            byte[] pdf = _gerador.Gerar(nomeAluno, curso);

            // Notifica a View
            OnDiplomaEmitido?.Invoke(this,
                new DiplomaEmitidoEventArgs(pdf));
        }
        catch (Exception ex)
        {
            OnValidacao?.Invoke(this,
                new ValidacaoEventArgs(false, ex.Message));
        }
    }
}