﻿using System;

/// Ponto de entrada da aplicação.
/// 
/// Responsável por:
/// - Criar objetos
/// - Ligar componentes
/// - Iniciar fluxo
class Program
{
    static void Main()
    {
        IGeradorDiploma gerador = new Gerador();
        Model model = new Model(gerador);
        View view = new View();
        Controller controller = new Controller(model);

        // Liga eventos
        view.Subscribir(model);
        view.OnEmitirDiploma += controller.EmitirDiploma;

        // Executa fluxo
        view.PedirEmissao();

        Console.ReadLine();
    }
}