﻿using System;

/// VIEW
/// Responsável pela interação com o utilizador
public class View
{
    /// Evento que envia input para o Controller
    public event Action<string, string>? OnEmitirDiploma;

    /// Subscrição aos eventos do Model
    public void Subscribir(Model model)
    {
        model.OnValidacao += MostrarValidacao;
        model.OnDiplomaEmitido += MostrarDiploma;
    }

    /// Simula input do utilizador
    public void PedirEmissao()
    {
        Console.WriteLine("Nome do aluno:");
        string nome = Console.ReadLine() ?? "";

        Console.WriteLine("Curso:");
        string curso = Console.ReadLine() ?? "";

        // Dispara evento para o Controller
        OnEmitirDiploma?.Invoke(nome, curso);
    }

    /// Mostra resultado da validação
    private void MostrarValidacao(object? sender, ValidacaoEventArgs e)
    {
        Console.WriteLine("[VIEW] " + e.Mensagem);
    }

    /// Mostra resultado final
    private void MostrarDiploma(object? sender, DiplomaEmitidoEventArgs e)
    {
        Console.WriteLine("[VIEW] Diploma gerado!");
        Console.WriteLine("[VIEW] Tamanho: " + e.PdfBytes.Length + " bytes");

        // Guarda ficheiro PDF
        System.IO.File.WriteAllBytes("diploma.pdf", e.PdfBytes);
    }
}